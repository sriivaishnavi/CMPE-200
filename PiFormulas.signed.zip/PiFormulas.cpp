#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main()
{
    //Assigning pi default value
    double pi = M_PI;
    
    //printing pi value
    cout << "pi   = " << setprecision(16) << pi  << " = 4*arctan(1)" << endl;

    
    cout << endl;
    cout << "Ramanujan's pi formulas:" << endl;
    
    //Determining pi value with precision 15
    double pi15;
    double l15 =   log( ((sqrt(5)+2) * (sqrt(13)+3))/ sqrt(2));
    double result15 = 12/sqrt(130);
    pi15 =  l15 * result15;

   //Determining pi value with precision 16
   double pi16;
   double l16 = log(sqrt((( sqrt(2) *11)+10)/4) + sqrt((( sqrt(2) *7)+10)/4));
   double result16 = 24/sqrt(142);
   pi16 = result16 * l16;

   //Determining pi value with precision 22
   double pi22;
   double l22 = log(((sqrt(5)+3)*(sqrt(2)+2)*(((sqrt(10)*2)+5)+sqrt((sqrt(10)*20)+61)))/4);
   double result22 = 12/sqrt(310);
   pi22 = result22*l22;

   //Determining pi value with precision 18
   double pi18;
   double l18 = log(((sqrt(2)*2)+sqrt(10))*(sqrt(10)+3));
   double result18 = 12/sqrt(190);
   pi18 = result18*l18;

   //Determining pi value with precision 31
   double pi31;
   double l31 = log(pow((sqrt(29)+5)/sqrt(2),3)*((sqrt(29)*5)+(sqrt(6)*11))*pow((sqrt(((sqrt(6)*3)+9)/4)+sqrt(((sqrt(6)*3)+5)/4)),6));
   double result31 = 4/sqrt(522);
   pi31 = result31 * l31;

   // printing pi with its precisions
   cout << "pi15 = " << setprecision(16) << pi15 << endl;
   cout << "pi16 = " << setprecision(16) << pi16 << endl;
   cout << "pi18 = " << setprecision(16) << pi18 << endl;
   cout << "pi22 = " << setprecision(16) << pi22 << endl;
   cout << "pi31 = " << setprecision(16) << pi31 << endl;
   cout << endl;
   
   //computimg eulers sum
   double eulers_sum;
   eulers_sum = (pi*pi)/6;
    

    cout << "Euler's infinite sum for pi*pi/6 = "<<setprecision(8) << eulers_sum  << endl;
   
   //finding interations 
   int n= 1;
   float sum = 0;

  do
  {
  
   float term =1/pow(n,2);
   if(term > pow(10, -8))
   {
   
    sum = sum + 1/pow(n,2);
    n++;
  }
  
  else
   {
     break;
     n++;
   }
  }while(n>0);

  float eulerspi;
  eulerspi=sqrt(sum *6);

  double error;

  
  error = pi - eulerspi;
  cout << "                      Converged to " << setprecision(8)<<sum
         << " after " << n << " iterations" << endl;
  cout<<endl;

  cout << "Euler's estimate for pi = "<< eulerspi << endl;
  cout << "                  error = " << setprecision(7)<<error << endl;
}